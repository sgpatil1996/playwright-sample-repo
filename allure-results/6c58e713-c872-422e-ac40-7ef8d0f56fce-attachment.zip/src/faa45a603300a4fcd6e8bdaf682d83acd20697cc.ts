import { test, expect } from '@playwright/test';
import * as testData from '../../data/testData.json';

test.describe('API Endpoint Integration Check', () => {
  test('POST /api/users - Should create a user record successfully', async ({ request }) => {
    const apiBaseUrl = process.env['qa.API_URL']  || 'https://petstore.swagger.io/v2';
    const payload = testData.postUser;

    const response = await request.post(`${apiBaseUrl}/store/order`, {
      data: payload
    });

    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    expect(responseBody).toHaveProperty('id');
    process.env['qa.EXPECTED_ID'] = String(responseBody.id);
    console.log(`Created order with ID: ${process.env['qa.EXPECTED_ID']}`);
    expect(responseBody.quantity).toBe(payload.quantity);
    expect(responseBody.complete).toBe(payload.complete);
    expect(responseBody.status).toBe(payload.status);

  });
})

//import { test, expect } from '@playwright/test';

test.describe('Get API Call Verification', () => {
  test('GET /store/order - Should retrieve the order record successfully', async ({ request }) => {
    const apiBaseUrl = process.env['qa.API_URL'] || 'https://petstore.swagger.io/v2';
    const orderId = process.env['qa.EXPECTED_ID'];

    // Ensure the ID was properly passed from the POST spec file
    expect(orderId).toBeDefined();
    console.log(`Fetching order with ID: ${orderId}`);

    // FIX: Changed ${{orderId}} to ${orderId}
    const response = await request.get(`${apiBaseUrl}/store/order/${orderId}`);
    
    // Assert the HTTP response status code is 200
    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    console.log('Received Response Body:', responseBody);

    // FIX: Verify actual schema values returned by the API
    expect(responseBody).toHaveProperty('id');
    expect(String(responseBody.id)).toBe(orderId);
  });
});

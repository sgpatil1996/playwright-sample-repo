import { test, expect } from '@playwright/test';
import { ApiMethods } from '../../pages/API/ApiMethods';
import testData from '../../data/testData.json';

test.describe('Petstore API - POST Endpoint', () => {
  test('Should dynamically post and append a new pet resource', async ({ request }) => {
    const payload = testData.postUser;

    const response = await request.post('/pet', { data: payload });
    
    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body.id).toBe(payload.id);
    expect(body.name).toBe(payload.name);
  });
});

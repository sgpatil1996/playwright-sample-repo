import { test, expect } from '@playwright/test';
import { ApiMethods } from '../../pages/API/ApiMethods';
import testData from '../../data/testData.json';

test.describe('Petstore API - GET Endpoint', () => {
  let petController: ApiMethods;
  const targetId = testData.postUser.id;

  test.beforeEach(async ({ request }) => {
    petController = new ApiMethods(request);
    
    // 🐕 Ensure the pet exists in the database first
    await petController.createPet(testData.postUser);
  });

  test('Should lookup and assert pet structures accurately', async () => {
    // Act
    const response = await petController.getPetById(targetId);
    
    // Assert status code
    expect(response.status()).toBe(200);
    
    // Assert structural body content
    const body = await response.json();
    expect(body.id).toBe(targetId);
    expect(body.name).toBe(testData.postUser.name);
  });
});

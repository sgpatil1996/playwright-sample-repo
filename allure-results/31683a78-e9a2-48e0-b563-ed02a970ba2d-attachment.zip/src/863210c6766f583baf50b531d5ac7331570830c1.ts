import { test, expect } from '@playwright/test';
import * as testData from '../../data/testData.json';

test.describe('API Endpoint Integration Check', () => {
  test('PUT /api/pet - Should update a pet record successfully', async ({ request }) => {
    const apiBaseUrl = process.env.API_URL || 'https://petstore.swagger.io/v2';
    const payload = testData.putUser;

    const response = await request.put(`${apiBaseUrl}/pet`, {
      data: payload
    });

    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    expect(responseBody).toHaveProperty('id');
    expect(responseBody.name).toBe(payload.name);
    expect(responseBody.name).toBe(payload.name);
    expect(responseBody.status).toBe(payload.status);

  });
})
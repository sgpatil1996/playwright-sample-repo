import { test, expect } from '@playwright/test';
import * as testData from '../../data/testData.json';

test.describe('Get API Call Verification', () => {
  test('GET /api/users - Should create a user record successfully', async ({ request }) => {
    const apiBaseUrl = process.env.API_URL || 'https://petstore.swagger.io/v2';
    //const payload = testData.apiUser;

    const response = await request.get(`${apiBaseUrl}/store/inventory`, {
    });

    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    expect(responseBody).toHaveProperty('sold');
    expect(responseBody.AAvailable).toBe("1");
    expect(responseBody.peric).toBe("8");
  });
})
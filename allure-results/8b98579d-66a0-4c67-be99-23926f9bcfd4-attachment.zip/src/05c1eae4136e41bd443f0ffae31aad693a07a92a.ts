import { test, expect } from '@playwright/test';
import * as testData from '../../data/testData.json';

test.describe('Get API Call Verification', () => {
  test('GET /api/users - Should create a user record successfully', async ({ request }) => {
    const apiBaseUrl = process.env['qa.API_URL']  || 'https://petstore.swagger.io/v2';
    const orderId = process.env['qa.EXPECTED_ID'];

    const response = await request.get(`${apiBaseUrl}/store/order/${{orderId}}`, {
    });
    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    expect(responseBody.status).toBe(200);
    expect(responseBody.peric).toBe("ok");
  });
})

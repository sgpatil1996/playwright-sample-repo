import { test, expect } from '@playwright/test';

test.describe('Get API Call Verification', () => {
  test('GET /store/order - Should retrieve the order record successfully', async ({ request }) => {
    const apiBaseUrl = process.env['qa.API_URL'] || 'https://petstore.swagger.io/v2';
    const orderId = process.env['qa.EXPECTED_ID'];

    // Ensure the ID was properly passed from the POST spec file
    expect(orderId).toBeDefined();
    console.log(`Fetching order with ID: ${orderId}`);

    // FIX: Changed ${{orderId}} to ${orderId}
    const response = await request.get(`${apiBaseUrl}/store/order/${orderId}`);
    
    // Assert the HTTP response status code is 200
    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    console.log('Received Response Body:', responseBody);

    // FIX: Verify actual schema values returned by the API
    expect(responseBody).toHaveProperty('id');
    expect(String(responseBody.id)).toBe(orderId);
  });
});

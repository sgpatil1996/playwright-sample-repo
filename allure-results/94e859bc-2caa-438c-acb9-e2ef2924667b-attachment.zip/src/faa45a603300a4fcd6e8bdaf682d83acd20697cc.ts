import { test, expect } from '@playwright/test';
import * as testData from '../../data/testData.json';

test.describe('API Endpoint Integration Check', () => {
  test('POST /api/users - Should create a user record successfully', async ({ request }) => {
    const apiBaseUrl = process.env['qa.API_URL']  || 'https://petstore.swagger.io/v2';
    const payload = testData.postUser;

    const response = await request.post(`${apiBaseUrl}/store/order`, {
      data: payload
    });

    expect(response.status()).toBe(200);
    
    const responseBody = await response.json();
    expect(responseBody).toHaveProperty('id');
    const expectedId = responseBody.id;
    console.log(`Created order with ID: ${expectedId}`);
    expect(responseBody.quantity).toBe(payload.quantity);
    expect(responseBody.complete).toBe(payload.complete);
    expect(responseBody.status).toBe(payload.status);

  });
})